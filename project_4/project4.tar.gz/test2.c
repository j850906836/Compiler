/*test for int,arithmetic computation,and printf*/ 
void main()
{
   float a;
   float b;
   a = 2.0;
   b = a+2.0*(1.0+(-100.0));
   printf("---The result of test2.c---\n");
   printf("I like to eat %f or %f bananas\n",b,a);
   printf("The number of bananas won't be negative,OK?\n");
   printf("------------END------------\n");
}
