void main(){
		float a;
		float b;
		float c;
		a = 5.0;
		b = 10.0;
		if(b > a){
			c = a;
		}
		else{
			c = b;
		}
		printf("---the result of test3---\n");
		printf("final C is %f\n", c);
		printf("---End testing if-else statement---\n");
}
